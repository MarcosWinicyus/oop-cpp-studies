#include "logica.h"

int main(){

    Logica* l = new Logica();
        l->start();

}