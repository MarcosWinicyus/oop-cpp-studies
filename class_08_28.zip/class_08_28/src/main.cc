#include "email.h"
#include "telefone.h"
#include "endereco.h"
#include <iostream>
#include <vector>
#include "pessoa.h"
#include "funcionario.h"
#include "empresario.h"
#include "logica.h"

int main(){

    Logica* l = new Logica();
        l->start();

}