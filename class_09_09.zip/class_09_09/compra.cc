#include "compra.h"

Pedido::~Pedido(){
    
}