#include "abstrata.h"

AbPessoa::~AbPessoa(){
    
}